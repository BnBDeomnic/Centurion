"use client";
import { Moon, Sun, User, Search } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation"; // untuk highlight halaman aktif
import { useTheme } from "../context/ThemeContext";

export default function Header() {
  const { darkMode, toggleTheme } = useTheme();
  const pathname = usePathname(); // ambil path saat ini

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Explore", href: "/Explore" },
    { name: "Bookmark", href: "/Bookmark" },
  ];

  return (
    <header
      className={`fixed top-4 left-1/2 -translate-x-1/2 w-[90%] max-w-6xl
                  rounded-2xl flex items-center justify-between px-6 py-3 z-50
                  transition-all duration-300 border
                  backdrop-blur-xl backdrop-saturate-150
                  ${
                    darkMode
                      ? "bg-transparent shadow-lg shadow-purple-900/40 border-purple-400/20"
                      : "bg-transparent shadow-lg shadow-yellow-500/40 border-yellow-300/30"
                  }`}
    >
      {/* Left: Logo */}
      <div className="flex items-center space-x-3">
        <Image
          src="/logo.png"
          alt="Logo"
          width={32}
          height={32}
          className="rounded-full"
        />
        <span
          className={`${
            darkMode ? "text-white" : "text-gray-900"
          } font-semibold text-lg tracking-wide`}
        >
          Centurion
        </span>
      </div>

      {/* Center: Nav + Search */}
      <div className="hidden md:flex flex-1 items-center justify-center space-x-6 px-6">
        {/* Navigation */}
        <nav className="flex items-center space-x-6">
          {navLinks.map((link, i) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={i}
                href={link.href}
                className={`text-sm font-medium transition-all duration-200 ease-out transform hover:scale-110
                  ${
                    darkMode
                      ? isActive
                        ? "text-yellow-400"
                        : "text-white hover:text-white hover:[text-shadow:0_0_6px_rgba(255,255,255,0.7)]"
                      : isActive
                      ? "text-purple-700"
                      : "text-gray-800 hover:text-gray-800 hover:[text-shadow:0_0_6px_rgba(0,0,0,0.3)]"
                  }`}
              >
                {link.name}
              </Link>
            );
          })}
        </nav>

        {/* Search Bar */}
        <div
          className={`flex items-center w-full max-w-xs rounded-xl px-3 py-2
                      border transition-all duration-300
                      ${
                        darkMode
                          ? "bg-white/10 border-purple-400/20"
                          : "bg-white/60 border-yellow-400/30"
                      }`}
        >
          <Search
            size={18}
            className={`mr-2 ${darkMode ? "text-white" : "text-gray-600"}`}
          />
          <input
            type="text"
            placeholder="Search..."
            className={`w-full bg-transparent outline-none text-sm
                        ${
                          darkMode
                            ? "text-white placeholder-gray-400"
                            : "text-gray-900 placeholder-gray-500"
                        }`}
          />
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center space-x-2">
        {/* Toggle Dark/Light */}
        <button
          aria-label="Toggle theme"
          className={`p-2 rounded-lg transition-all duration-200 transform hover:scale-110
                      ${darkMode ? "hover:bg-white/10" : "hover:bg-gray-200/60"}`}
          onClick={toggleTheme}
        >
          {darkMode ? (
            <Sun size={20} className="text-yellow-500" />
          ) : (
            <Moon size={20} className="text-purple-700" />
          )}
        </button>

        {/* User */}
        <button
          aria-label="User profile"
          className={`p-2 rounded-lg transition-all duration-200 transform hover:scale-110
                      ${
                        darkMode
                          ? "text-white hover:bg-white/10"
                          : "text-black hover:bg-gray-200/60"
                      }`}
        >
          <User size={20} />
        </button>
      </div>
    </header>
  );
}
