import "./globals.css";
import type { Metadata } from "next";
import { ThemeProvider } from "../../context/ThemeContext";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "Book Library",
  description: "Portfolio with Next.js + Tailwind v4",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
